require('./current_file').file(__filename);

/*
* [GR:0006:stable]
* new Buffer with string
*/
var a = new Buffer('test')


/*
* [GR:0006:stable]
* new Buffer with array
*/
var a = new Buffer([1, 2, 3])
