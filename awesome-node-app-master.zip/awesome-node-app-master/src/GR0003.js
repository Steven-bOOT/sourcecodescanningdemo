require('./current_file').file(__filename);

/*
* [GR:0003:stable]
* Set config for markup escape detected: Mustache
*/

// XXX Can not find any evidence of escapeMarkup in the mustache.js package.
// object.escapeMarkup = false
