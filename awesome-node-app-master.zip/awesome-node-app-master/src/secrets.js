require('./current_file').file(__filename);

let aLongSecret =
  'eafc0093a2b9a14e86ed8d3cb43c31f8e58147728f489550773545566bc7dda5';

let password = 'IShouldNotBeFound';

import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import * as serviceWorker from './serviceWorker';

ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById('root')
);

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();

var user="xyz";
var password="test123";

var AWS_ACCESS_KEY = "askdfhlksfdjadslkfjsfklj1232l3klsdkfjdsf";
var AWS_SECRET_ACCESS_KEY = "slkdajflsadf";
var PWD = "askldfjlsadf";
var API_KEY = "sdfasdf";
var access_key = "sdfsdf";
var AWS_SECRET_ACCESS_KEY = "TestKeyPassPwd";
var DSA_PRIVATE_KEY = "sdkflasaskdjfhjksdhfkdsjf";
var myVal = "-----BEGIN RSA PRIVATE KEY-----\n
MIIBOQIBAAJBAIOLepgdqXrM07O4dV/nJ5gSA12jcjBeBXK5mZO7Gc778HuvhJi+\n
RvqhSi82EuN9sHPx1iQqaCuXuS1vpuqvYiUCAwEAAQJATRDbCuFd2EbFxGXNxhjL\n
loj/Fc3a6UE8GeFoeydDUIJjWifbCAQsptSPIT5vhcudZgWEMDSXrIn79nXvyPy5\n
BQIhAPU+XwrLGy0Hd4Roug+9IRMrlu0gtSvTJRWQ/b7m0fbfAiEAiVB7bUMynZf4\n
SwVJ8NAF4AikBmYxOJPUxnPjEp8D23sCIA3ZcNqWL7myQ0CZ/W/oGVcQzhwkDbck\n
3GJEZuAB/vd3AiASmnvOZs9BuKgkCdhlrtlM6/7E+y1p++VU6bh2+mI8ZwIgf4Qh\n
u+zYCJfIjtJJpH1lHZW+A60iThKtezaCk7FiAC4= \n
-----END RSA PRIVATE KEY-----";
var AWS_SECRET_KEY = "TestKeyPassPwasdlfsdfasdfd";
var DSA_PRIVATE_KEY = "My Private Key is here";
var git_token = "3cb43625bb5a9a7f58498517asdsadas7sa7d687a5sd78sa6d";
var gpg_key = "8sa7d8sa7d0sa7dsa7d98sad7sa6d7sa6d98sads8a7d0sad7sa87d89sa7d98sa7d98sa7d8sad";
var key = "4dsf245dsf896ds8f59ds65f4fdf587F5ds8dsf95ds87f";
var ssh_key = "Y2QwMWU0ZWUtOWZkMy00YjIxLThkMmYtMmVkYWFhZTBhMDI2OjEwZmYxMTQ3LWY4ZTAtNDU3ZC05ZGRlLWZhMWMzN2E1MWRjMA==";
var ssh_key = "Y2QwMWU0ZWUtOWZkMy00YjIxLThkMmYtMmVkYWFhZTBhMDI2OjEwZmYxMTQ3LWY4ZTAtNDU3ZC05ZGRlLWZhMWMzN2E1MTyuMA==";
var openssh_private_key = "mytest";
var SUMMVED_Password = "Slsdfl";
var AKC_TOKEN = "sakdfjlsdf";
var summved = 'test';
var summved2 = "testing232183test";
var test_keys = 'jsabdsafdsfjkbdsakfsbdlf';
var har_har_mahadev = 'lknajankjclbsaljdf765943534m5n4b6';
var har_har = 'lknajankjclbsaljdf765943534m5n4b6';
var har_hars = 'lknajankjclbsaljdf765943534m5n4b6';
var hars = 'lknajankjclbsaljdf765943534m5n4b6';
var mahardev = 'lknajankjclbsaljdf765943534m5n4b6';
var hars_hars = 'lknajankjclbsaljdf765943534m5n4b6';
