# A repository with ALL the JavaScript vulnerabilities

## Dependencies

- `hoek` version 5.0.0: [NSWG-367](https://github.com/nodejs/security-wg/blob/a3425e433e4b8e7c99c0d3244491b215b2554f55/vuln/npm/367.json)

## SourceCode

- all of them

## Secrets

- quite a few of them
